//
//  ImageViewController.swift
//  Group-HECK_Picture_Translator
//
//  Created by Reinhart, Emily J on 4/22/19.
//  Copyright © 2019 Reinhart, Emily J. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController {

    var image: UIImage!
    var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let imageView = UIImageView(frame: view.frame)
        imageView.image = image
        view.addSubview(imageView)
        
        setupCloseButton()
        setupActivityIndicator()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func setupCloseButton() {
        let closeButton = UIButton()
        view.addSubview(closeButton)
        
        // Stylistic features.
        closeButton.setTitle("✕", for: .normal)
        closeButton.setTitleColor(UIColor.white, for: .normal)
        closeButton.titleLabel?.font = UIFont.systemFont(ofSize: 32)
        
        // Add a target function when the button is tapped.
        closeButton.addTarget(self, action: #selector(closeAction), for: .touchDown)
        
        // Constrain the button to be positioned in the top left corner (with some offset).
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        closeButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 20).isActive = true
    }
    
    @objc private func closeAction() {
        dismiss(animated: false, completion: nil)
    }

    private func setupActivityIndicator() {
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
        view.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        activityIndicator.startAnimating()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
